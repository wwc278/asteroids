!function ($) {
  $.ender({
    key: require('keymaster')
  })
}(ender)